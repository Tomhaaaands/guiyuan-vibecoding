---
name: vibe-coding-manager
description: Explicit-only skill (implicit auto-selection disabled). Invoke with $vibe-coding-manager to put any coding project — an existing script, plugin, page, or app — under local iteration management, or to scaffold a brand-new project in an empty folder. Guides target, state detection, environment preflight with upfront install disclosure, management shell, git/GitHub, and a plain-language closing report.
---

# Web Coding Manager (guided)

One skill, one conversation: whatever the user brings — a script, a plugin, a page, a full app,
or nothing but an empty folder — the outcome is the same: a locally managed project with the
iteration loop (AGENTS startup contract, changelog/archive/NOW, deterministic gates). The
generator is only the empty-folder path; **managing what already exists is the core.**

Conversation-first: speak the user's language and keep it plain. Zero-base users (e.g. just
started with Doubao / Workbuddy) may not know git, Python, Node, or `.venv` — never assume they
do. Explain anything they will need to understand, in one plain sentence.

## Stage 0 · Opening (always first)

Reply (wording may vary, but must contain these items):

> I'm your project's local manager. I can take any coding project — a script, a plugin, a page,
> or a full app — and set up local management for it **without touching your code**. If you have
> an empty folder, I can also create the project for you.
> Please give me:
> 1. Project location: a local folder, or a GitHub repository URL (default: current directory)
> 2. Project name (default: the folder name)

## Stage 1 · State detection

Check the target before asking anything else:

- **Empty folder** (or only `.git`) → **scaffold path**. First ask what they want to build:
  - script / plugin / page (map to `--profile script|plugin|page`)
  - full app → keep the existing questions: project type presets (saas / c-end / vector-db /
    cli-tool / custom dimensions) and modules (web / api / db / worker / tests, or the default
    template web+api+db+worker+tests)
- **Folder has code** → **adopt path**. Run detection (fingerprints: `manifest.json` → plugin;
  `package.json` deps → page/app; `pyproject.toml`/`requirements.txt` → app/script;
  `index.html` → static page; a single root script file → script). Tell the user plainly what
  was detected and promise: business code stays untouched; only missing management files are added.

## Stage 2 · Environment preflight & disclosure (before any install)

Run the read-only preflight and show what's found (git / python / node / uv / gh), then state in
plain language exactly what this project needs installed and why — e.g. ".venv is an isolated
environment that belongs only to this project and won't change anything else on your computer."
Then offer three choices:

1. **Auto-install (recommended)** — I run the installs now (`--deps auto`);
2. **Commands only** — I print the exact commands and you run them later (`--deps commands`);
3. **Skip** — I only add the management layer, no installs (`--deps skip`).

Never install anything before this choice is made.

## Stage 3 · Execute

```bash
python <skill path>/scripts/bootstrap.py <folder> --name <project> --mode auto|adopt|scaffold \
    [--profile script|plugin|page|saas|c-end|vector-db|cli-tool|path/to.toml] \
    [--module web --module api ...] [--code "name=dir"] [--template default] \
    [--dimension "key=value"] [--python auto|system|install|<path>] \
    [--env auto|shared|isolated|reuse|skip] [--deps auto|commands|skip] \
    [--github <repo-url>] [--push]
```

- adopt: detection picks the profile automatically (`script`/`plugin`/`page`) and adds the runtime
  dimension; pass `--force` only if the user explicitly wants to replace management files —
  business code is never overwritten;
- scaffold: artifact choice maps to `--profile script|plugin|page`; full app uses modules/presets;
- GitHub: if the user gave a repo URL or wants one, set origin with `--github <url>`, and push
  (`--push`) only after they have authenticated (`gh auth login` or git credentials) and confirmed.

The script: state detection -> copies only missing management files (adopt) or the full skeleton
(scaffold) -> replaces placeholders -> applies the profile (constraints / red lines / gitignore)
-> writes `.env.example` when missing -> R1 archive -> llms.txt -> dependency handling per the
Stage 2 choice -> `git init` -> pre-commit gate -> installs `iteration-close-loop` if missing ->
GitHub remote/push -> plain-language report.

## Stage 4 · Verify

Run `tools/check_drift.py` in the target; hard markers must be 0; list remaining `{{placeholders}}`.

## Stage 5 · Closing (always, plain language)

> Done ✅ Your project is under local management.
> - Detected: <type> — your code was not changed (adopt) / skeleton created (scaffold)
> - Installed: ... (or: commands are printed above / nothing installed)
> - Git/GitHub: ...
> Next: open a new conversation here and start your first real task. Every round gets a changelog
> row, an archive file, and a gate check automatically.

## Rules

- Stage 0 always precedes everything; Stage 1 state detection decides adopt vs scaffold;
- Deploy only user-confirmed modules; never guess names/keywords/code dirs;
- Idempotent: never overwrite existing files unless `--force`; in adopt mode business code is
  never overwritten even with `--force`;
- No installs before the Stage 2 disclosure choice; explain every install in plain language;
- After the closing report, stop asking business details and guide to a new conversation.
